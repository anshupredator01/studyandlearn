# Initiate Payment

Once you have `EasyUpiPayment` instance built successfully. You are ready to initiate payment.

Initiate payment using `startPayment()` method.

<!-- tabs:start -->

#### ** Kotlin **

```kotlin
easyUpiPayment.startPayment()
```

#### ** Java **

```java
easyUpiPayment.startPayment();
```

<!-- tabs:end -->

You'll get Status of payment/transaction through callback/listener. Let's see about it in next section.
