![logo](media/icon.png)

# Easy UPI Payment <small>📱Android</small>

> Android Library to implement UPI Payment integration easily in Android App 💳💸

- Simple and lightweight
- Easy Setup
- Supports almost all used UPI apps.

[Get Started](/?id=easy-upi-payment-android-library)
[GitHub](https://github.com/PatilShreyas/EasyUpiPayment-Android)
[Maven Central](https://search.maven.org/artifact/dev.shreyaspatil.EasyUpiPayment/EasyUpiPayment)
