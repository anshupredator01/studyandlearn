package com.shreyaspatil.easyupipayment

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class FakeUpiActivity : AppCompatActivity() {

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		finish()
	}
}